# windows-kill
**[Documents](https://github.com/alirdn/windows-kill)**